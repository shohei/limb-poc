# Linkcal
```
$ python linkcal.py config.ini
```

